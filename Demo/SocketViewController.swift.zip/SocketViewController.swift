//
//  SocketViewController.swift
//  Demo
//
//  Created by phan.van.da on 4/8/19.
//  Copyright © 2019 phan.van.da. All rights reserved.
//

import UIKit
import SocketIO

let manager = SocketManager(socketURL: URL(string: "http://113.164.94.103:3000")!, config: [.log(true), .compress])
let param = [
    "user_name": "admin",
    "pass": "admin"
]

class SocketViewController: UIViewController {
    let socket = manager.defaultSocket
    
    override func viewDidLoad() {
        super.viewDidLoad()
        socket.connect()
        
        socket.on("SERVER_SEND_RESULT_LOGIN") { (data, ack) in
            print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
            print(data)
        }
        
        socket.on("connect") { (data, ack) in
            print("connected")
        }
        
    }
    
    @IBAction func login(_ sender: Any) {
        socket.emit("CLIENT_REQUEST_AUTHENTICATE_LOGIN", param)
        
        if self.socket.status == .connected {
            print("aaaaaaa")
        }
    }
}
